<?php
    session_start();
    include "connect.php";
    $id = $_SESSION['id'];
    $sql = "SELECT * FROM karyawan WHERE id='$id'";
    $query = mysqli_query($conn, $sql);
    $data = mysqli_fetch_array($query);
    $role = $data['role'];
    $_SESSION['nama'] = $data['nama'];
    switch($role) {
        case "Owner":
            header("Location:owner/");
            break;
        case "Sekretaris":
            header("Location:sekretaris/");
            break;
        case "Bendahara":
            header("Location:bendahara/");
            break;
        case "Kasir":
            header("Location:kasir/");
            break;
        case "Operator":
            header("Location:operator/");
            break;
        case "Customer Service":
            header("Location:cs/");
            break;
    }
?>
