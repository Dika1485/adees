<?php
error_reporting(E_ALL ^ E_DEPRECATED ^ E_NOTICE);

$host = 'localhost';
$user = 'root';
$pass = '';
$db = 'laundry_ads';

$conn = mysqli_connect($host, $user, $pass, $db) or die('Gagal menyambungkan ke database...');
?>
